# Responsive schedule / timetable | jQuery

A Pen created on CodePen.io. Original URL: [https://codepen.io/Manel-Daza-Sanchez/pen/WNmBRwE](https://codepen.io/Manel-Daza-Sanchez/pen/WNmBRwE).

![alt text](https://s26.postimg.org/tfum45j7t/screenshot_537.png "Schedule")