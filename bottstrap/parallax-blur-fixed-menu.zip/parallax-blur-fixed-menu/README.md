# Parallax + Blur + Fixed menu

A Pen created on CodePen.io. Original URL: [https://codepen.io/nodws/pen/mdQoEB](https://codepen.io/nodws/pen/mdQoEB).

Simple single page starter framework, Medium blog-like-ish

Logo loses opacity and moves vertically, background blurs and the menu wait for it... gets fixed to the top